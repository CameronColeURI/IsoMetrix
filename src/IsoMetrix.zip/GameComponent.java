import java.awt.*;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.image.BufferedImage;
import java.io.IOException;

import javax.imageio.ImageIO;
import javax.swing.*;


public class GameComponent extends JComponent implements MouseListener
{
	private static final long serialVersionUID = 1L;
	private Image image = null;
	private int iWidth2;
	private int iHeight2;
	
	public IsoMetrixOrganizer iSorganizer;

	public GameComponent()
	{
		this.image = readImage("grassTest");
		this.iWidth2 = image.getWidth(this)/2;
		this.iHeight2 = image.getHeight(this)/2;
		
		addMouseListener(this);	
		
//		System.out.println(iWidth2);
		
		iSorganizer = new IsoMetrixOrganizer(iWidth2);
	}
	
	public GameComponent(Image image)
	{
		this.image = image;
		this.iWidth2 = image.getWidth(this)/2;
		this.iHeight2 = image.getHeight(this)/2;
		
		iSorganizer = new IsoMetrixOrganizer(iWidth2);
	}

	@Override
	protected void paintComponent(Graphics g)
	{
		super.paintComponent(g);
		//setDoubleBuffered(true);
		
		if (image != null)
		{
			int x = this.getParent().getWidth()/2 - iWidth2;
			int y = this.getParent().getHeight()/2 - iHeight2;
			g.drawImage(image,x,y,this);
		}
		
		iSorganizer.paint(g);
	}
	
	public Image readImage(String fileName)
	{
		Image img = null;
		try {
			img = ImageIO.read(getClass().getResource("resources/" + fileName + ".png"));
			img = img.getScaledInstance(GUI.WINDOW_W, GUI.WINDOW_H, Image.SCALE_DEFAULT);
		} catch (IOException e) {
		}

		return img;
	}
	
	/**
	 * Obvious MouseListener implementations
	 */
	public void mouseClicked(MouseEvent event)
	{
		iSorganizer.check(isoClick);	
		repaint();
	}

	public void mouseEntered(MouseEvent event){}
	public void mouseExited(MouseEvent event){}

	
	private void flipWhenInside()
	{

		repaint();
	}

	@Override
	public void mousePressed(MouseEvent event)
	{
		isoClick.x = event.getX();	
		isoClick.y = event.getY();
		
		System.out.println(isoClick);
		
		flipWhenInside();	
	}

	@Override
	public void mouseReleased(MouseEvent event)
	{
		flipWhenInside();	
	}
	
	private Point isoClick = new Point();
}
