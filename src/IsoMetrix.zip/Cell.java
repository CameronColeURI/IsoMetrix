import java.awt.*;


public class Cell
{
	private int x, y;
	
	Point[] twoDPts, isoPts;
	
	private int width, height;
	
	private int num;
	
	private boolean highlight = false;
	
	public Cell(int x, int y, int width, int height, int num, int xOffset)
	{
		this.width = width;
		this.height = height;
		
		this.x = x;	//2d pts
		this.y = y;
		
		twoDPts = new Point[]{
				new Point(x,y),	//top left corner
				new Point(x + width, y), //top right corner
				new Point(x + width, y + height), //bot right corner
				new Point(x, y + height) //bot left corner			
		};
		
		isoPts = new Point[]{
				twoDToIso(twoDPts[0], xOffset),
				twoDToIso(twoDPts[1], xOffset),
				twoDToIso(twoDPts[2], xOffset),
				twoDToIso(twoDPts[3], xOffset)
		};
		
		this.num = num;
	}
	
	public Point twoDToIso(Point pt, int xOffset)
	{
		Point tempPt = new Point(x,y);

		tempPt.x = pt.x - pt.y;
		tempPt.y = (pt.x + pt.y)/2;

		return tempPt;
	}
	
	public Point isoTo2D(Point pt, int xOffset)
	{
		Point tempPt = new Point(x,y);
		
		tempPt.x = (2 * pt.y + pt.x)/2;
		tempPt.y = (2 * pt.y - pt.x)/2;
		
		System.out.println(tempPt);
		
		return tempPt;
	}
	
	public boolean isInside(Point pt)
	{
		boolean inside = false;
		
		if ((pt.x > x) && (pt.x < (x + width)))
			if ((pt.y > y) && (pt.y < (y + height)))
				inside = true;
		
		return inside;
	}
	
	public void paint(Graphics pane, boolean draw2D, boolean drawIso)
	{
		if (draw2D)
		{
			int[] xP = new int[]{twoDPts[0].x, twoDPts[1].x, twoDPts[2].x,
					twoDPts[3].x};

			int[] yP = new int[]{twoDPts[0].y, twoDPts[1].y,
					twoDPts[2].y, twoDPts[3].y};

			pane.setColor(Color.red);
			pane.drawPolygon(xP, yP, 4);
			
			if (highlight)
				pane.fillPolygon(xP, yP, 4);
			
			Font f = new Font("Text", Font.BOLD, 20);
			pane.setFont(f);
			pane.drawString("" + num, x + width/2, y + height/2);
		}

		if (drawIso)
		{		
			pane.setColor(Color.blue);

			int[] iX = new int[]{isoPts[0].x, isoPts[1].x, isoPts[2].x,
					isoPts[3].x};

			int[] iY = new int[]{isoPts[0].y, isoPts[1].y,
					isoPts[2].y, isoPts[3].y};

			pane.drawPolygon(iX, iY, 4);
			
			if (highlight)
				pane.fillPolygon(iX, iY, 4);
			
		}

		Font d = new Font("Text", Font.PLAIN, 12);
		pane.setFont(d);
		
	}
	
	
	public void setHighlight(boolean h)
	{
		this.highlight = h;
	}
	
	
}
