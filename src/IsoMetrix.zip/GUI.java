import java.awt.*;
import javax.swing.*;



public class GUI						
{	
	private static GameComponent gameComp;
	private static ButtonPanel butPanel;
	
	public final static int WINDOW_W = 800, WINDOW_H = 600;
	
	public static void main(String[] args) {
		SwingUtilities.invokeLater(new Runnable() {
			public void run() {
				createAndShowGUI();
			}
		});
	}
	
	private static void createAndShowGUI()
	{
		System.out.println("Created GUI on EDT? "+
                SwingUtilities.isEventDispatchThread());
		
		JFrame f = new JFrame("IsoMetrix");
		
		f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		f.setSize(WINDOW_W, WINDOW_H);
		
		Dimension dim = Toolkit.getDefaultToolkit().getScreenSize();
		f.setLocation(dim.width/2-f.getSize().width/2, dim.height/2-f.getSize().height/2);
		
		gameComp = new GameComponent();
		butPanel = new ButtonPanel(gameComp);
		
		f.add(gameComp, BorderLayout.CENTER);
		f.add(butPanel, BorderLayout.NORTH);
		
		f.setVisible(true);
	}			
}
