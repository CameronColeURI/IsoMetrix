import java.awt.event.*;
import java.awt.*;

import javax.swing.*;

public class IsoMetrixOrganizer extends JFrame

{	
	private int xOffset;
	
	private LinkedCollection cellGrid;
	
	private boolean show2D = false, showIso = false;
	
	public IsoMetrixOrganizer(int xOffset)
	{
		this.xOffset = xOffset;

		cellGrid = new LinkedCollection();
		placeGrid();
	}

	private void placeGrid()	//in 2d
	{
		int width = 70, height = 70;
		int xP, yP;
		
		for (int i = 0; i < 10; i++)
		{
			for (int j = 0; j < 10; j++)
			{
				xP = (j * width);
				yP = (i * height);
				
				cellGrid.add(new Cell(xP, yP, width, height, (10 * i) + j, xOffset));
			}
		}
	}	
	
	public void check(Point isoClick)
	{
		cellGrid.reset();
		Cell current = cellGrid.next();
		
		Point twoDClick = current.isoTo2D(isoClick, xOffset);
		
		while (cellGrid.hasNext())
		{
			if (current.isInside(twoDClick))  //change to get tile coordinates?
				System.out.println(twoDClick);
			
			current = cellGrid.next();
		}
		cellGrid.reset(current);
//		repaint();
	}
	
	public void paint(Graphics pane)
	{	
		//painting the grid
		if (cellGrid != null)
		{
			cellGrid.reset();
			cellGrid.paint(pane, show2D, showIso);
			System.out.println("painting");
		}
	}
	

	public boolean getShow2D()
	{
		return this.show2D;
	}

	public void setShow2D(boolean b)
	{
		this.show2D = b;
		
	}		
	
	public boolean getShowIso()
	{
		return this.showIso;
		
	}
	
	public void setShowIso(boolean b)
	{
		this.showIso = b;
	}
}
